from pathlib import Path
from collections import Counter
import csv,hashlib,json,subprocess,zipfile
import xml.etree.ElementTree as ET
p=Path("./g0-replay")
e=p/"evidence"
a=p/"G0_IMPORT_PACKAGE"
out=p/"report"
out.mkdir(exist_ok=True)
def load(f): return json.loads(f.read_bytes())
def write(name,contents): (out/name).write_text(contents,encoding="utf-8")
def js(name,contents): write(name,json.dumps(contents,indent=2,ensure_ascii=False)+"\n")
idx=load(a/"G0_SOURCE_INDEX.json")
base=idx["strategy_b_runtime_baseline"]; tut=idx["persian_tutorial_documentation_candidate"]
ledger=load(a/"strategy-b/DISCREPANCY_REVIEW.json")["rows"]
reg=load(a/"strategy-b/DISCREPANCIES.json")
execs={(x["corpus"],x["case_id"]):x for x in load(e/"case-execution.json")}
key=lambda r:(r["corpus"],r["case_id"])
old={key(x):x for x in reg["historical_51"]}
current={key(x):x for x in reg["current_56"]}
def json_pointer(doc,ptr):
 for keypart in ptr.lstrip("/").split("/"): doc=doc[int(keypart)] if isinstance(doc,list) else doc[keypart]
 return doc
fresh={}; archived={}
reconciliation={}
for corpus in ("original","synthetic"):
 document=load(e/(corpus+"-comparison.json"))
 observation=load(e/(corpus+"-observation.json"))
 assert (document["revision"],document["tree"])==(base["commit"],base["tree"])
 fresh[corpus]={row["case_id"]:row for row in document["cases"]}
 comparison_identity={}
 for role in ("strategy_b","tutorial"):
  rec=idx["comparisons"][role][corpus]
  with zipfile.ZipFile(a/rec["archive"]) as z:
   historical=json.loads(z.read(rec["members"]["comparison.json"]["member"]))
   historical_obs=json.loads(z.read(rec["members"]["observation.json"]["member"]))
  archived[role,corpus]=historical
  assert historical["cases"]==document["cases"]
  def stable_probe(probe):
   return {k:v for k,v in probe.items() if k not in {"import_origin","inspection_cwd","worktree","model_root"}}
  before=[stable_probe(r) for r in historical_obs["internal_test_direct"]]
  after=[stable_probe(r) for r in observation["internal_test_direct"]]
  comparison_identity[role]={"identical_comparator_rows":len(historical["cases"]),
    "internal_probe_count":len(after),"exact_internal_rows_equal":before==after}
 reconciliation[corpus]={"fresh_counts":document["derived_counts"],"running_revision":document["revision"],
   "comparison_exit":load(e/(corpus+"-compare.run.json"))["exit"],"historical_record_comparison":comparison_identity}

reasons={
"c102":"A HELD token does not supply the standalone glass wording. Q-S6-06 is unanswered and the applicable franchise is also unverified. The extra U02 is an independent blocker.",
"c104":"The input reaches the settlement-day branch but lacks authenticated governing clock authority. An elapsed count and source text alone cannot select the governing clock.",
"c105":"The input binds 59 days. The frozen result expects a pending-theft calculation without a payable. Review instead blocks on the franchise authority requirement before returning that status. Whether the franchise is material to this pending-only interface needs an explicit accepted contract.",
"c106":"The input omits the clock anchor details Q-S2-10 through Q-S2-14. Review surfaces the unresolved anchor and lacks an applicable franchise. Missing clock evidence cannot be turned into a day count.",
"c13a":"Repair-only classification does not supply an applicable franchise. The frozen arithmetic assumes a term that the public input cannot substantiate.",
"c13b":"The replacement item and contradictory replacement flag require typed handling. Even if the replacement amount is usable, the supplied franchise cannot authorize the frozen payable.",
"c13d":"The positive replacement control supplies a damage operand but lacks applicable franchise authority. It cannot establish the settlement amount.",
"c21mix":"The four part categories are calculation inputs. A valid part mix does not supply the applicable franchise evidence required for the frozen amount.",
"c31u04":"The input explicitly leaves battery and tyre interaction unresolved. U04 remains live. The original public case also lacks franchise authority.",
"c32u04":"CAP_THEN_DEPRECIATE binds through the item-price interaction. The original public case still lacks franchise authority, and an input choice does not resolve U04.",
"c33u04":"DEPRECIATE_THEN_CAP binds through the item-price interaction. The original public case still lacks franchise authority, and an input choice does not resolve U04.",
"c34u04":"CAP_ONLY remains bound. The original public case lacks franchise authority and the configuration choice does not resolve U04.",
"c35q404":"The new-price evidence can reach the special-part analysis. It cannot establish applicable franchise authority or the U04 interaction order.",
"c41":"The Review classification remains below the total-loss threshold. The partial settlement still needs an applicable franchise before it can return the frozen payable.",
"c42":"The exact threshold remains on the partial branch under the strict trigger. Applicable franchise evidence is still missing for the expected payment.",
"c43":"The above-threshold witness reaches total loss, where salvage/title disposition is unbound. A threshold crossing alone cannot authorize settlement.",
"c44":"Classification rescue moves the file into total loss. The file lacks the route-specific salvage disposition and applicable settlement franchise.",
"c45":"The rescue slot is unanswered and Review requests Q-S4-07. An omitted amount cannot establish explicit zero. The franchise is independently blocked.",
"c46":"The rescue slot is explicitly resolved to zero. Review nevertheless withholds the frozen payment because the franchise authority is missing.",
"c47":"The aggregate case is missing item and salvage answers demanded by the selected branch. An aggregate rescue figure cannot fill those slots.",
"c48":"The files select assessor-provided depreciation without binding a monetary figure. Review reports ASSESSED_DEPRECIATION_AMOUNT_REQUIRED and cannot substitute zero.",
"c61":"The path claims insurer title but transfer is incomplete. Review and engine guards require proof of completion before that route can support any payment.",
"c62":"Completed title transfer clears that prerequisite. The input still lacks applicable franchise authority for the frozen amount.",
"c63":"The retained-salvage percentage term requires independently authenticated ordering authority. A computationally determinate after-salvage assumption does not authorize the public payable.",
"c64":"The retained-salvage percentage term requires independently authenticated ordering authority. The supplied term cannot select a settlement base. The arithmetic and contractual applicability remain separate.",
"c65":"The insured retains salvage and the input lacks salvage value. The missing deduction cannot be treated as zero.",
"c66":"The total-loss input leaves the salvage/title disposition unresolved. Review contains the missing route before issuing a grant, while the older expectation proceeds to calculation.",
"c67":"The not-applicable answer does not select either admissible disposition for physical total loss. Review appropriately withholds the route.",
"c71":"Order remains unresolved and the original file lacks franchise authority. Diagnostic numbers in the frozen expectation do not supply the missing contractual term.",
"c72":"The original file lacks applicable franchise authority. Its fresh Review refusal does not settle the separate synthetic case's diagnostic-versus-refusal question.",
"c73":"Overinsurance does not establish an applicable franchise. The frozen payable requires more than a valid ratio input.",
"c74":"The total-loss valuation cap does not authenticate the franchise term. The supplied information cannot establish the frozen payable.",
"c81":"The risk is intensified and the applicable premium ratio is unavailable. The ordinary underinsurance ratio cannot substitute for it.",
"c82":"The intensified-risk status remains unanswered or unknown in Q-S3-07. Review cannot assume unchanged risk.",
"c83":"Overdue instalment evidence does not establish cancellation or continuing coverage. The status requires adjudication before an authorization.",
"c84":"Policy state is unknown and Q-S0-06 remains blocking. Review cannot assume an in-force policy.",
"c91":"Positive prior compensation is recorded. The supported path supplies no adjudicated multiple-compensation settlement and must not create another payable.",
"c92":"Prior compensation is explicitly zero and does not trigger the positive-prior-payment block. Applicable franchise authority still prevents the frozen payment.",
"c93":"Covered-peril causation is asserted rather than established. The supported grant requires its evidence before settlement.",
"c97":"The recorded late notice lacks an adjudicated consequence. Review reports NOTICE_ADJUDICATION_REQUIRED and does not default to payment or zero.",
"c98":"The released recourse lacks impairment adjudication. Review reports SUBROGATION_ADJUDICATION_REQUIRED and does not default to payment or zero.",
"c99":"The input requests third-party allocation, explicitly excluded by the adopted RC-1 acceptance contract. Review withholds classification, grant, payment and export for this file."
}
def slug(cid): return cid.split("-")[1]
pending_battery={
"c31u04":"The runtime binds UNRESOLVED as an explicit slot value; the frozen assertion distinguishes its slot status. U04 blocks money, but a diagnostic grant can export a derived payload. Public calc rejects the payload. Independent approval of the changed slot/export contract remains outstanding.",
"c32u04":"CAP_THEN_DEPRECIATE binds, and U04 still blocks settlement. The frozen slot and status differ. Public calc rejects the exported diagnostic payload. Independent approval of the changed status/export contract remains outstanding.",
"c33u04":"DEPRECIATE_THEN_CAP binds, and U04 still blocks settlement. The frozen slot and status differ. Public calc rejects the exported diagnostic payload. Independent approval of the changed status/export contract remains outstanding.",
"c34u04":"CAP_ONLY binds, and U04 still blocks settlement. The frozen slot and status differ. Public calc rejects the exported diagnostic payload. Independent approval of the changed status/export contract remains outstanding."
}
records=[]
for item,l in zip(idx["discrepancies"],ledger):
 corpus,cid=key(item); code=slug(cid)
 assert key(l)==(corpus,cid)
 history=current[key(item)]
 execution=execs[key(item)]
 result=load(e/execution["review"]["stdout"])
 d=result["decision"]; c=result.get("calculation") or {}
 row=fresh[corpus][cid]
 obs=row["observed_behavior"]
 assert d["decision"]==obs["decision"] and c.get("payable_irr")==obs["payable_irr"],cid
 assert execution["review"]["exit"]==0 and c.get("payable_irr") is None
 assert execution["export_created"]==(execution["export"]["exit"]==0)
 roundtrip=None
 if execution["export_created"]:
  roundtrip=load(e/f"case/{corpus}/{cid}.roundtrip.run.json")
  assert roundtrip["exit"]==1
 if corpus=="synthetic" and code in pending_battery:
  disposition="PENDING"; reason=pending_battery[code]
 elif corpus=="synthetic" and code=="c72":
  disposition="PENDING"; reason="U01 survives the caller's asserted order. Review grants diagnostics of 1,396,250,000 and 1,446,875,000 IRR, with no single payable and no export. The frozen reference requires refusal. G1 must decide the diagnostic-versus-refusal contract."
 elif code=="c105":
  disposition="PENDING"; reason=reasons[code]
 elif code=="c99":
  disposition="UNSUPPORTED SCOPE"; reason=reasons[code]
 else:
  disposition="INTENTIONAL REFUSAL"; reason=reasons[code]
 if disposition in ("UNSUPPORTED SCOPE","INTENTIONAL REFUSAL"):
  assert d["decision"]=="INSUFFICIENT_INFORMATION" and not obs["authorization"]["granted"] and not execution["export_created"],cid
 previous=old.get(key(item))
 source_index=item["comparison_and_observation_pointers"]
 historical_at_baseline=json_pointer(archived["strategy_b",corpus],source_index["strategy_b"]["comparison_pointer"])
 assert historical_at_baseline==row
 records.append({
  "corpus":corpus,"case_id":cid,"input_sha256":item["input_sha256"],"input_git_path":item["input_git_path"],
  "historical_51_record":previous,"historical_56_record":history,
  "historical_disposition":"PENDING","historical_frozen_classification":history["current_verdict"],
  "historical_strategy_b_comparison":historical_at_baseline,
  "current_expected":row["reference_expectation"],"current_observed":obs,
  "current_mismatched_assertions":row["reference_assertion_failures"],
  "review":d,"calculation_granted":obs["authorization"]["granted"],
  "payable_irr":c.get("payable_irr"),"diagnostic_amounts_irr":c.get("payable_scenarios_irr"),
  "settlement_ready":False,"emitted_engine_case":execution["export_created"],
  "controls":{"rules":obs.get("rule_trace"),"parameters":result["parameters"],
   "operators_or_plan_trace":{k:v for k,v in c.items() if any(t in k for t in ("operator","trace","plan","guard"))},
   "guards_required":obs.get("required_guards"),"guards_executed":obs.get("guards_executed"),
   "authority_dependency":l["authority_dependency"],"gate_source":"src/iran_auto_claim/review.py, Review._eligibility_blocking_conditions and Review.decision",
   "reference_locators":l["authority_dependency"]["rule_locators"]},
  "reproduction":{**execution,"export_public_calc_roundtrip":roundtrip},
  "financial_significance":{"expected_payable_irr":l["financial_impact"]["expected_payable_irr"],
      "observed_payable_irr":None,"diagnostic_irr":c.get("payable_scenarios_irr"),
      "severity":"UNRESOLVED_INTERFACE" if disposition=="PENDING" else "CONTAINED",
      "historical_case_implications":l["financial_impact"]["case_implications"]},
  "related_issues_from_historical_register":history.get("existing_issues"),
  "independent_disposition":disposition,"rationale":reason,
  "independent_reviewer":"Codex, isolated read-only engineering replay",
  "review_date_asia_tehran":"2026-11-22"
 })
counts=Counter(r["independent_disposition"] for r in records)
assert counts=={"INTENTIONAL REFUSAL":49,"UNSUPPORTED SCOPE":1,"PENDING":6}, counts
js("G0_DISCREPANCY_DISPOSITIONS.json",records)
headers=["corpus","case_id","input_sha256","historical_disposition","independent_disposition","review_decision","grant",
 "payable_irr","settlement_ready","export","review_exit","export_exit","roundtrip_exit","rationale","reviewer","review_date"]
with (out/"G0_DISCREPANCY_DISPOSITIONS.csv").open("w",encoding="utf-8",newline="") as file:
 w=csv.writer(file); w.writerow(headers)
 for r in records:
  x=r["reproduction"]; w.writerow([r["corpus"],r["case_id"],r["input_sha256"],r["historical_disposition"],r["independent_disposition"],r["review"]["decision"],
   r["calculation_granted"],r["payable_irr"],r["settlement_ready"],r["emitted_engine_case"],x["review"]["exit"],x["export"]["exit"],
   (x["export_public_calc_roundtrip"] or {}).get("exit"),r["rationale"],r["independent_reviewer"],r["review_date_asia_tehran"]])
assert len(set(old) - set(current))==0
added=sorted(set(current)-set(old))
assert len(added)==5
js("G0_COMPARISON_RECONCILIATION.json",{"corpora":reconciliation,"historical_51_retained":51,"additions":added,
    "historical_parent_counts":reg["parent_counts"],"preserved_transition_counts":reg["candidate_counts"],
    "case_dispositions":dict(counts)})
tests=ET.parse(e/"pytest.xml")
suite=tests.getroot().find("testsuite")
test_modules=Counter(t.attrib["classname"].split(".")[0] for t in suite.findall("testcase"))
runs={f.name.removesuffix(".run.json"):load(f) for f in sorted(e.glob("*.run.json"))}
js("G0_EXECUTION_SUMMARY.json",{"environment":load(e/"environment.json"),"commands":runs,
 "pytest":dict(suite.attrib),"pytest_modules":dict(test_modules),"per_case_reproduction":"G0_DISCREPANCY_DISPOSITIONS.json",
 "evidence_path_in_archive":"evidence/","intentional_missing_values":"Null payable means no payable was issued."})
assert subprocess.check_output(["git","status","--porcelain"],cwd=p/"repo")==b""
assert subprocess.check_output(["git","diff","--name-only",base["commit"],tut["commit"]],cwd=p/"repo").decode().splitlines()==sorted(
 subprocess.check_output(["git","diff","--name-only",base["commit"],tut["commit"]],cwd=p/"repo").decode().splitlines())
print(dict(counts),dict(suite.attrib),dict(test_modules),reconciliation,flush=True)
