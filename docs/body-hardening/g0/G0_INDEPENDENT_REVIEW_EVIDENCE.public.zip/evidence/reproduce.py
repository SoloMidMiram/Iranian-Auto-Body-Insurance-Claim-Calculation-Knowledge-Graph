from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,platform,subprocess,sys,time
p=Path("./g0-replay")
e=p/"evidence"
root=p/"repo"
py=str(p/"venv/bin/python")
env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1","PYTHONPYCACHEPREFIX":str(p/"pycache"),"PYTEST_ADDOPTS":"-p no:cacheprovider","PYTHONUTF8":"1","HYPOTHESIS_STORAGE_DIRECTORY":str(p/"hypothesis")}
index=json.loads((p/"G0_IMPORT_PACKAGE/G0_SOURCE_INDEX.json").read_bytes())
def run(name,args):
    started=time.monotonic()
    result=subprocess.run([py,*args],cwd=root,env=env,capture_output=True)
    out=e/(name+".stdout")
    err=e/(name+".stderr")
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_bytes(result.stdout)
    err.write_bytes(result.stderr)
    rec={"argv":[py,*args],"cwd":str(root),"exit":result.returncode,"seconds":round(time.monotonic()-started,3),
         "stdout":out.relative_to(e).as_posix(),"stderr":err.relative_to(e).as_posix(),
         "stdout_sha256":hashlib.sha256(result.stdout).hexdigest(),"stderr_sha256":hashlib.sha256(result.stderr).hexdigest()}
    (e/(name+".run.json")).write_text(json.dumps(rec,indent=2)+"\n")
    print(name,result.returncode,flush=True)
    return rec
def corpus(corp,cases,manifest):
    o=e/f"{corp}-observation.json"
    c=e/f"{corp}-comparison.json"
    run(corp+"-inspect",["-I","-S","-B","-X","utf8","scripts/run_case_based_inspection.py","--root",".","--cases",cases,"--manifest",manifest,"--internal","--output",str(o)])
    if o.exists():
        run(corp+"-compare",["-I","-S","-B","-X","utf8","scripts/build_case_comparison.py",str(o),str(c),"--model-root",".","--cases",cases,"--manifest",manifest])
def case(r):
    name="case/"+r["corpus"]+"/"+r["case_id"]
    target=e/(name+".export.json")
    target.parent.mkdir(parents=True,exist_ok=True)
    review=run(name+".review",["-B","claim.py","review",r["input_git_path"],"--json","--calc"])
    export=run(name+".export",["-B","claim.py","review",r["input_git_path"],"--emit-case",str(target)])
    return {"corpus":r["corpus"],"case_id":r["case_id"],"review":review,"export":export,"export_created":target.exists()}
def safety():
    for name,args in [
        ("full-suite",["-m","pytest","--junitxml="+str(e/"pytest.xml")]),
        ("strict-stage0",["-m","pytest","--runxfail","tests/test_stage0_counterexamples.py"]),
        ("fixtures",["claim.py","fixtures"]),
        ("knowledge",["claim.py","validate"]),
        ("mutation",["scripts/run_mutation_gate.py","--check-report"]),
    ]: run(name,args)
(e/"environment.json").write_text(json.dumps({"platform":platform.platform(),"python":sys.version,"test_executable":py,"environment":{k:env[k] for k in ("PYTHONDONTWRITEBYTECODE","PYTHONPYCACHEPREFIX","PYTEST_ADDOPTS","PYTHONUTF8","HYPOTHESIS_STORAGE_DIRECTORY")},"revision":index["strategy_b_runtime_baseline"]},indent=2)+"\n")
with ThreadPoolExecutor(max_workers=3) as pool:
    jobs=[pool.submit(safety),pool.submit(corpus,"original","cases","docs/case-reference-manifest-v1.json"),
          pool.submit(corpus,"synthetic","docs/reconciliation-evidence/synthetic-v1","docs/reconciliation-evidence/synthetic-reference-v1.json")]
    with ThreadPoolExecutor(max_workers=3) as cases:
        results=list(cases.map(case,index["discrepancies"]))
    (e/"case-execution.json").write_text(json.dumps(results,indent=2)+"\n")
    for job in jobs:job.result()
